# Odinheim
Odinheim Modpack

## Details
A collection of mods to improve gameplay

### Changelog

**1.0.0**

	- Initial Upload
	- Changelog Not Implemented Yet
	
**1.0.1 - 1.1.2**

	- Tweaks and Fixes
	- Changelog Not Implemented Yet

**2.0.0**

	- Changelog Implemented
	- Restructured Modpack
	- Added `BepInExPack_Valheim`
	- Added `Jotunn`
	- Added `CustomSlotItemLib`
	- Added `Odinheim_Core`
	- Added `Odinheim_QoL`
	- Added `Odinheim_Extras`
	
**2.0.1**

	- Removed `CustomSlotItemLib`
	- Removed `Odinheim_QoL`

**2.2.0 - 2.2.2**

	- Tweaks and Improvements
	- Updated `Odinheim Core`
	- Updated `Odinheim Extras`
	- Reimplemented `Odinheim QoL`